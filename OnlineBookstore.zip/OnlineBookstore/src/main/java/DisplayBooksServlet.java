import jakarta.servlet.http.HttpServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

//import DBConnectionManager;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/displayBooks")
public class DisplayBooksServlet extends HttpServlet {
	
	private static final String query = "SELECT * FROM books";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    	
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        //DBConnectionManager dbManager = new DBConnectionManager();
        //Connection connection = null;
        // For trial Purpose ONly
        try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        try {
        	
  
        	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/BookstoreDB", "root", "Pass10a100%");
        	
        	
            //connection = dbManager.getConnection();
            //Statement stmt = connection.createStatement();
            
        	PreparedStatement ps = conn.prepareStatement(query);
        	
        	ResultSet rs = ps.executeQuery(query);
        	
        	out.println("<h3> Search Book </h3>");
        	out.println("<form action = 'searchBook' method = 'post' >");
       
        	out.println("<input type = 'text' name = 'keyword' >");
        	
        	out.println("<input type = 'submit' value = 'submit' >");
        	
        	out.println("</form>");
            out.println("<table border='1'>");
            out.println("<tr><th>ID</th><th>Book Title </th><th>Book Author </th><th>Price</th></tr>");
            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + rs.getInt("id") + "</td>");
                out.println("<td>" + rs.getString("title") + "</td>");
                out.println("<td>" + rs.getString("author") + "</td>");
                out.println("<td>" + rs.getInt("price") + "</td>");
                
                out.println("<td><a href ='deleteBook?id=" + rs.getInt(1) + "'> Delete </a></td>");

                out.println("</tr>");
            }
            out.println("</table>");
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}