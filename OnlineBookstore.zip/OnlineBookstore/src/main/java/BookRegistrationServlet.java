

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

//import DBConnectionManager;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/register")

public class BookRegistrationServlet extends HttpServlet {
	
    private static final String INSERT_QUERY = "INSERT INTO Books (title, author, price) VALUES (?, ?, ?)" ;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    	
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        
        try {
			Class.forName("com.mysql.cj.jdbc.Driver");  //For Trial Purpose Only
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        try {
        	
        	String title = req.getParameter("title");
            String author = req.getParameter("author");
            int price = Integer.parseInt(req.getParameter("price"));
            
            //For Trial Purpose Only
        	
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/BookstoreDB", "root", "Pass10a100%");
            
//            DBConnectionManager dbManager = new DBConnectionManager();
//            Connection connection = null;

           
                //connection = dbManager.getConnection();
                
                PreparedStatement ps = conn.prepareStatement(INSERT_QUERY);
			
                //PreparedStatement ps = conn.prepareStatement(INSERT_QUERY);

	            // Set query parameters
	            ps.setString(1, title);
	            ps.setString(2, author);
	            ps.setInt(3, price);

	            // Execute query
	            int rowsInserted = ps.executeUpdate();
	            if (rowsInserted > 0) {
	                out.println("<h3>Book added successfully!</h3>");
	            } else {
	                out.println("<h3>Error adding book!</h3>");
	            }

		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
    }

        
   
    @Override
    
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    	
    	doGet(req, res);
    }
}
